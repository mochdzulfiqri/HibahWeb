<footer id="footer">
    <div class="container py-4">
        <div class="copyright">
            &copy; Copyright <strong><span>PMIIDev</span></strong> <?= date('Y'); ?>
        </div>
        <div class="credits">
            Designed by <a href="https://www.pmii.id/">PMIIDev</a>
        </div>
    </div>
</footer>